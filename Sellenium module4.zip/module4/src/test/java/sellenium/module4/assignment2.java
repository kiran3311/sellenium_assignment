package sellenium.module4;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import io.github.bonigarcia.wdm.WebDriverManager;

public class assignment2 {

	public static void main(String[] args) throws IOException, InterruptedException {
		WebDriverManager.chromedriver().setup();
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://itechnotion.com/what-will-be-the-cost-of-an-app-like-justdial-its-indias-no-1-local-business-directory/");
		List<WebElement> headers =  driver.findElements(By.tagName("h2"));
		System.out.println("headers");
		for(WebElement i: headers) {
			System.out.println(i.getText());
		}
		
		System.out.println("\n");
		
		driver.findElement(By.xpath("//a[normalize-space()='Solutions']")).click();
		List<WebElement> feature = driver.findElements(By.xpath("//*[@id=\"navigation\"]/ul/li[4]/ul/li"));
		System.out.println("Features");
		for (WebElement u : feature) {
			System.out.println(u.getText());
		}
		
		System.out.println("\n");
		driver.findElement(By.xpath("//a[normalize-space()='Customers']")).click();
		List<WebElement> technology = driver.findElements(By.xpath("//*[@id=\"navigation\"]/ul/li[1]/ul/li[3]/ul/li"));
		List<WebElement> technology2 = driver.findElements(By.xpath("//*[@id=\"navigation\"]/ul/li[1]/ul/li[4]/ul/li"));
		technology.addAll(technology2);
		
		for (WebElement x : technology) {
			System.out.println(x.getText());
		}
		
		driver.findElement(By.xpath("//div[@class='btn btn-primary btn_custom']")).click();
		
		File file = new File("C:\\Users\\Lenovo\\eclipse-workspace\\module4\\resources\\testdata2.xlsx");
		FileInputStream inputStream = new FileInputStream(file);
		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
		XSSFSheet sheet = workbook.getSheetAt(0);
		int totalRow = sheet.getLastRowNum()+1;
		int totalCell = sheet.getRow(0).getLastCellNum();
		
		for (int currentRow=1; currentRow<totalRow; currentRow++) {
			driver.findElement(By.xpath("//input[@id='FIRSTNAME']")).sendKeys(sheet.getRow(currentRow).getCell(0).toString());
			driver.findElement(By.xpath("//input[@id='EMAIL']")).sendKeys(sheet.getRow(currentRow).getCell(1).toString());
			
			XSSFCell cell = sheet.getRow(currentRow).getCell(2);
			String phone = NumberToTextConverter.toText(cell.getNumericCellValue());
			driver.findElement(By.xpath("//input[@name='SMS']")).sendKeys(phone);
			
			WebElement interest = driver.findElement(By.xpath("//*[@id=\"IT_INTEREST\"]"));
			Select selectInterest = new Select(interest);
			selectInterest.selectByValue("2");
			
			WebElement budget = driver.findElement(By.xpath("//*[@id=\"IT_BUDGET\"]"));
			Select selectBudget =new Select(budget);
			selectBudget.selectByValue("1");
			
			WebElement req = driver.findElement(By.xpath("//*[@id=\"IT_REQUIREMENT\"]"));
			Select selectReq = new Select(req);
			selectReq.selectByValue("1");
			
			driver.findElement(By.xpath("//textarea[@id='MESSAGE']")).sendKeys("demo testing");
			driver.findElement(By.xpath("//*[@id=\"sib-form\"]/div[10]/div/button")).click();
		}
		 Thread.sleep(5000);
		driver.quit();		
		
	}
}
