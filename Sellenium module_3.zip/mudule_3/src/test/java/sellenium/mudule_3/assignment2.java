package sellenium.mudule_3;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;

public class assignment2 {
	WebDriver driver;
	
	@BeforeMethod
	public void setup() {
		
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
	}
	
	@Test
	public void login() throws IOException, InterruptedException {
		//Create an object of File class to open xlsx file
		File file = new File("C:\\Users\\Lenovo\\eclipse-workspace\\mudule_3\\resources\\testdata.xlsx");
		
		//Create an object of FileInputStream class to read excel file
		FileInputStream inputStream = new FileInputStream(file);
		
		//If it is xlsx file then create object of XSSFWorkbook class
		XSSFWorkbook workbook = new XSSFWorkbook(inputStream);
		
		//create object of XSSFSheet to acces the perticular sheet
		XSSFSheet sheet = workbook.getSheetAt(0);
		
		//find total number of row present in sheet
		int totalRow = sheet.getLastRowNum()+1;
		
		//find total number of cell present in perticular row
		int totalCell = sheet.getRow(0).getLastCellNum();
		
		//itterating with the help of for loop to get value of each cell
		for (int currentRow=1; currentRow<totalRow; currentRow++) {
			driver.get("https://demo.guru99.com/test/login.html");
			driver.findElement(By.id("email")).sendKeys(sheet.getRow(currentRow).getCell(0).toString());
			driver.findElement(By.id("passwd")).sendKeys(sheet.getRow(currentRow).getCell(1).toString());
			driver.findElement(By.id("SubmitLogin")).click();
			Thread.sleep(3000);
		}
			
		
	}
	
	@AfterMethod
	public void closer() {
		driver.quit();
	}
	

}
