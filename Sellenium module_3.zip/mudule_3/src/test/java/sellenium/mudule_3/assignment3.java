package sellenium.mudule_3;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.*;

import io.github.bonigarcia.wdm.WebDriverManager;

public class assignment3 {
     WebDriver driver;
     
     
     @BeforeTest
	public void setup() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		
		
		
	}
	
	@Test(priority=1, groups= {"smoke","regration"})
	public void forms() throws InterruptedException {
		
		driver.get("https://demoqa.com/");
		
		
		driver.findElement(By.xpath("//div[@class='home-body']//div[2]//div[1]//div[1]")).click();
		
	}
	
	
	@Test(priority=2 , groups= {"smoke","regration"})
	public void practiceForm() {
		
		driver.findElement(By.xpath("//span[text()=\"Practice Form\"]")).click();
		
	}
	
	@Test(priority=3, groups= "regration")
	public void fillForm() throws InterruptedException {
		
		JavascriptExecutor js =(JavascriptExecutor)driver;
		js.executeScript("document.body.style.zoom='50%'");
		Thread.sleep(3000);
		driver.findElement(By.xpath("//input[@id=\"firstName\"]")).sendKeys("Kiran");
		driver.findElement(By.xpath("//input[@id=\"lastName\"]")).sendKeys("Gangurde");
		driver.findElement(By.xpath("//input[@id=\"userEmail\"]")).sendKeys("Kiran@gmail.com");
		
		WebElement radio = driver.findElement(By.xpath("//label[@for='gender-radio-1']"));
		js.executeScript("arguments[0].click()", radio);
		
		driver.findElement(By.xpath("//input[@id='userNumber']")).sendKeys("1234567890");
		driver.findElement(By.xpath("//input[@id=\"subjectsInput\"]")).sendKeys("Coding");
		
		WebElement checkbox =driver.findElement(By.xpath("//input[@id='hobbies-checkbox-3']"));
		js.executeScript("arguments[0].click()", checkbox);
		driver.findElement(By.xpath("//textarea[@id=\"currentAddress\"]")).sendKeys("Nashik");
		WebElement country = (driver.findElement(By.xpath("//*[@id=\"state\"]/div/div[1]")));
		
		js.executeScript("arguments[0].click()", country);
		
		WebElement select = driver.findElement(By.xpath("//input[@id='react-select-3-input']"));
		js.executeScript("arguments[0].click()", select);
		
		WebElement btn = driver.findElement(By.xpath("//button[@id='submit']"));
		js.executeScript("arguments[0].click()", btn);
	}
	
	@AfterTest
	public void closer() {
		driver.quit();
	}
}
